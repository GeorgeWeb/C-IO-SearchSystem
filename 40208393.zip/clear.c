#include <stdio.h>

int main()
{
	/** cuz' design matters (: + my eyes can't handle all the text displayed there.
	  * Not really important line at all but.. (:
	*/
	system("cls"); // I know that the use of system is a bad practice but the thing is that I only use it for such small programs.
	
	return 0;
}